# De Vertrouwensmeter v4.0

> Wetenschappelijk gefundeerde organisatiediagnostiek op basis van het **ABI-model** (Mayer, Davis & Schoorman, 1995) en het **McKinsey 7S-framework**.

🔗 **Live app:** [bekijk op GitHub Pages](https://jouwgebruikersnaam.github.io/project-vertrouwen)

---

## Wat is dit?

De Vertrouwensmeter is een standalone webapplicatie waarmee organisaties het **vertrouwensklimaat** kunnen meten via 12 wetenschappelijk onderbouwde Likert-items, verdeeld over 4 dimensies:

| Dimensie | ABI-component | Vragen |
|----------|---------------|--------|
| Toekomst · Strategie | Ability | S1, S2, S3 |
| Systemen · Integrity | Integrity | I1, I2, I3 |
| Management · Ability | Ability + Benevolence | M1, M2, M3 |
| Medewerkers · Benevolence | Benevolence | B1, B2, B3 |

---

## Functies

- 📊 **Dashboard** — gemiddelden, ABI-verdeling, afdelingsscores
- 📈 **Trendlijn** — historische data over 7 kwartalen
- ✉️ **Uitnodigen** — respondenten uitnodigen via e-mail
- 🔒 **Anonieme modus** — naam en niveau worden niet opgeslagen
- 📁 **Export** — CSV (Excel/SPSS) en tekstrapport
- 🏢 **Living Office Scene** — kantoor reageert live op de vertrouwensscore

---

## Gebruik

Open `index.html` in een browser — geen installatie, geen server nodig.

---

## Wetenschappelijk kader

- Mayer, R. C., Davis, J. H., & Schoorman, F. D. (1995). An integrative model of organizational trust. *Academy of Management Review*, *20*(3), 709–734.
- Luhmann, N. (1979). *Trust and power*. Wiley.
- McAllister, D. J. (1995). Affect- and cognition-based trust. *Academy of Management Journal*, *38*(1), 24–59.

---

## Versiegeschiedenis

| Versie | Inhoud |
|--------|--------|
| v1 | Basisschuifregelaars, ABI-verdeling |
| v2 | Dashboard, trendlijn, export |
| v2b | Anonieme modus, e-mailfunctie |
| v2c | Standalone kantoorscène |
| v3.0 | Alles geïntegreerd, sticky kantoorscène |
| **v4.0** | **3 Likert-items per dimensie, voortgangsbalk** |

---

*Gebouwd voor gebruik in onderwijs- en organisatieonderzoek.*
